import React from "react";
export default function Home () {
  return (
    <div className="bgimg">

  <div className="middle">
    <h1>Error Page ....</h1>

  </div>
  <div className="bottomleft">
  </div>
</div>
  );
}
