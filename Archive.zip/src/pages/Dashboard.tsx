import React from "react";
export default function Dashboard () {
  return (
    <div className="bgimg">

  <div className="middle">
    <h1>Dashboard Page ....</h1>

  </div>
  <div className="bottomleft">
  </div>
</div>
  );
}
