import React from 'react'

export default function Header() {
    return (
        <div>
            <h1>Header</h1>
        </div>
    )
}
