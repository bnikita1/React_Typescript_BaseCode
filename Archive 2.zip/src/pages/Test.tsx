// import { faUserCircle } from "@fortawesome/free-solid-svg-icons";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";

export default function Test () {
  return (
    <div className="content">
      <input type="text" value="nikita" className="test" placeholder="hi" name="test" id="test"/>
    </div>
  );
}
