import React from "react";
export default function Home () {
  return (
    <div className="bgimg">

  <div className="middle">
    <h1>COMING SOON ....</h1>

  </div>
  <div className="bottomleft">
  </div>
</div>
  );
}
